export interface patientlist {
  Patient_id: string;
  Patient_name: string;
  Program: string;
  Weeks_remaining: string;
  Assigned_member:string;
  Vitals:string;
  Interactions:string
}
