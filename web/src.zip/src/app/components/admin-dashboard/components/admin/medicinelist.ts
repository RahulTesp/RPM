export interface medicinelist {
  medicine_name: string;
  category: string;
  Applicable_for_Symptoms: string;
  remarks: string;
}
