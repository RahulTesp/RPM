export interface TaskData {

  AllTasks: string;
  Patient_Name: string;
  All_Programs: string;
  created_by: string;
  Due_Date:string,
  Status:string

}
