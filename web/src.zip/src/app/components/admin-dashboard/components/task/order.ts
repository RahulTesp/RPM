export interface Order {
  id: number;
  description: string;
  amount: number;
  price: number;
  discount: number;
}
